"use strict";
/**
 * @license
 * Copyright 2019 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
exports.__esModule = true;
var tf = require("@tensorflow/tfjs-core");
var keypoints_1 = require("../keypoints");
function getScale(_a, _b, _c) {
    var height = _a[0], width = _a[1];
    var inputResolutionY = _b[0], inputResolutionX = _b[1];
    var _d = _c[0], padT = _d[0], padB = _d[1], _e = _c[1], padL = _e[0], padR = _e[1];
    var scaleY = inputResolutionY / (padT + padB + height);
    var scaleX = inputResolutionX / (padL + padR + width);
    return [scaleX, scaleY];
}
function toPersonKSegmentation(segmentation, k) {
    return tf.tidy(function () { return segmentation.equal(tf.scalar(k)).toInt(); });
}
exports.toPersonKSegmentation = toPersonKSegmentation;
function toPersonKPartSegmentation(segmentation, bodyParts, k) {
    return tf.tidy(function () { return (segmentation.equal(tf.scalar(k)).toInt().mul(bodyParts.add(1)))
        .sub(1); });
}
exports.toPersonKPartSegmentation = toPersonKPartSegmentation;
function decodeMultipleMasksTensorGPU(segmentation, longOffsets, posesAboveScore, height, width, stride, _a, _b, refineSteps, minKptScore, maxNumPeople) {
    var inHeight = _a[0], inWidth = _a[1];
    var _c = _b[0], padT = _c[0], padB = _c[1], _d = _b[1], padL = _d[0], padR = _d[1];
    // The height/width of the image/canvas itself.
    var _e = segmentation.shape, origHeight = _e[0], origWidth = _e[1];
    // The height/width of the output of the model.
    var _f = longOffsets.shape.slice(0, 2), outHeight = _f[0], outWidth = _f[1];
    longOffsets = longOffsets.reshape([outHeight, outWidth, 2, keypoints_1.NUM_KEYPOINTS]);
    // Make pose tensor of shape [MAX_NUM_PEOPLE, NUM_KEYPOINTS, 3] where
    // the last 3 coordinates correspond to the score, h and w coordinate of that
    // keypoint.
    var poseVals = new Float32Array(maxNumPeople * keypoints_1.NUM_KEYPOINTS * 3).fill(0.0);
    for (var i = 0; i < posesAboveScore.length; i++) {
        var poseOffset = i * keypoints_1.NUM_KEYPOINTS * 3;
        var pose = posesAboveScore[i];
        for (var kp = 0; kp < keypoints_1.NUM_KEYPOINTS; kp++) {
            var keypoint = pose.keypoints[kp];
            var offset = poseOffset + kp * 3;
            poseVals[offset] = keypoint.score;
            poseVals[offset + 1] = keypoint.position.y;
            poseVals[offset + 2] = keypoint.position.x;
        }
    }
    var _g = getScale([height, width], [inHeight, inWidth], [[padT, padB], [padL, padR]]), scaleX = _g[0], scaleY = _g[1];
    var posesTensor = tf.tensor(poseVals, [maxNumPeople, keypoints_1.NUM_KEYPOINTS, 3]);
    var program = {
        variableNames: ['segmentation', 'longOffsets', 'poses'],
        outputShape: [origHeight, origWidth],
        userCode: "\n    int convertToPositionInOutput(int pos, int pad, float scale, int stride) {\n      return round(((float(pos + pad) + 1.0) * scale - 1.0) / float(stride));\n    }\n\n    float convertToPositionInOutputFloat(int pos, int pad, float scale, int stride) {\n      return ((float(pos + pad) + 1.0) * scale - 1.0) / float(stride);\n    }\n\n    float dist(float x1, float y1, float x2, float y2) {\n      return pow(x1 - x2, 2.0) + pow(y1 - y2, 2.0);\n    }\n\n    float sampleLongOffsets(float h, float w, int d, int k) {\n      float fh = fract(h);\n      float fw = fract(w);\n      int clH = int(ceil(h));\n      int clW = int(ceil(w));\n      int flH = int(floor(h));\n      int flW = int(floor(w));\n      float o11 = getLongOffsets(flH, flW, d, k);\n      float o12 = getLongOffsets(flH, clW, d, k);\n      float o21 = getLongOffsets(clH, flW, d, k);\n      float o22 = getLongOffsets(clH, clW, d, k);\n      float o1 = mix(o11, o12, fw);\n      float o2 = mix(o21, o22, fw);\n      return mix(o1, o2, fh);\n    }\n\n    int findNearestPose(int h, int w) {\n      float prob = getSegmentation(h, w);\n      if (prob < 1.0) {\n        return -1;\n      }\n\n      // Done(Tyler): convert from output space h/w to strided space.\n      float stridedH = convertToPositionInOutputFloat(\n        h, " + padT + ", " + scaleY + ", " + stride + ");\n      float stridedW = convertToPositionInOutputFloat(\n        w, " + padL + ", " + scaleX + ", " + stride + ");\n\n      float minDist = 1000000.0;\n      int iMin = -1;\n      for (int i = 0; i < " + maxNumPeople + "; i++) {\n        float curDistSum = 0.0;\n        int numKpt = 0;\n        for (int k = 0; k < " + keypoints_1.NUM_KEYPOINTS + "; k++) {\n          float dy = sampleLongOffsets(stridedH, stridedW, 0, k);\n          float dx = sampleLongOffsets(stridedH, stridedW, 1, k);\n\n          float y = float(h) + dy;\n          float x = float(w) + dx;\n\n          for (int s = 0; s < " + refineSteps + "; s++) {\n            int yRounded = round(min(y, float(" + (height - 1.0) + ")));\n            int xRounded = round(min(x, float(" + (width - 1.0) + ")));\n\n            float yStrided = convertToPositionInOutputFloat(\n              yRounded, " + padT + ", " + scaleY + ", " + stride + ");\n            float xStrided = convertToPositionInOutputFloat(\n              xRounded, " + padL + ", " + scaleX + ", " + stride + ");\n\n            float dy = sampleLongOffsets(yStrided, xStrided, 0, k);\n            float dx = sampleLongOffsets(yStrided, xStrided, 1, k);\n\n            y = y + dy;\n            x = x + dx;\n          }\n\n          float poseScore = getPoses(i, k, 0);\n          float poseY = getPoses(i, k, 1);\n          float poseX = getPoses(i, k, 2);\n          if (poseScore > " + minKptScore + ") {\n            numKpt = numKpt + 1;\n            curDistSum = curDistSum + dist(x, y, poseX, poseY);\n          }\n        }\n        if (numKpt > 0 && curDistSum / float(numKpt) < minDist) {\n          minDist = curDistSum / float(numKpt);\n          iMin = i;\n        }\n      }\n      return iMin;\n    }\n\n    void main() {\n        ivec2 coords = getOutputCoords();\n        int nearestPose = findNearestPose(coords[0], coords[1]);\n        setOutput(float(nearestPose));\n      }\n  "
    };
    var webglBackend = tf.backend();
    var result = webglBackend.compileAndRun(program, [segmentation, longOffsets, posesTensor]);
    return result;
}
function decodeMultipleMasksGPU(segmentation, longOffsets, poses, height, width, stride, _a, _b, minPoseScore, refineSteps, minKeypointScore, maxNumPeople) {
    var inHeight = _a[0], inWidth = _a[1];
    var _c = _b[0], padT = _c[0], padB = _c[1], _d = _b[1], padL = _d[0], padR = _d[1];
    if (minPoseScore === void 0) { minPoseScore = 0.2; }
    if (refineSteps === void 0) { refineSteps = 8; }
    if (minKeypointScore === void 0) { minKeypointScore = 0.3; }
    if (maxNumPeople === void 0) { maxNumPeople = 10; }
    return __awaiter(this, void 0, void 0, function () {
        var posesAboveScore, masksTensor, multiPersonSegmentation;
        var _this = this;
        return __generator(this, function (_e) {
            switch (_e.label) {
                case 0:
                    posesAboveScore = poses.filter(function (pose) { return pose.score >= minPoseScore; });
                    masksTensor = decodeMultipleMasksTensorGPU(segmentation, longOffsets, posesAboveScore, height, width, stride, [inHeight, inWidth], [[padT, padB], [padL, padR]], refineSteps, minKeypointScore, maxNumPeople);
                    return [4 /*yield*/, Promise.all(posesAboveScore.map(function (pose, i) { return __awaiter(_this, void 0, void 0, function () {
                            var data;
                            return __generator(this, function (_a) {
                                switch (_a.label) {
                                    case 0: return [4 /*yield*/, toPersonKSegmentation(masksTensor, i).data()];
                                    case 1:
                                        data = (_a.sent());
                                        return [2 /*return*/, { height: height, width: width, data: data, pose: pose }];
                                }
                            });
                        }); }))];
                case 1:
                    multiPersonSegmentation = _e.sent();
                    return [2 /*return*/, multiPersonSegmentation];
            }
        });
    });
}
exports.decodeMultipleMasksGPU = decodeMultipleMasksGPU;
function decodeMultiplePartMasksGPU(segmentation, longOffsets, partSegmentation, poses, height, width, stride, _a, _b, minPoseScore, refineSteps, minKeypointScore, maxNumPeople) {
    var inHeight = _a[0], inWidth = _a[1];
    var _c = _b[0], padT = _c[0], padB = _c[1], _d = _b[1], padL = _d[0], padR = _d[1];
    if (minPoseScore === void 0) { minPoseScore = 0.2; }
    if (refineSteps === void 0) { refineSteps = 8; }
    if (minKeypointScore === void 0) { minKeypointScore = 0.3; }
    if (maxNumPeople === void 0) { maxNumPeople = 10; }
    return __awaiter(this, void 0, void 0, function () {
        var posesAboveScore, masksTensor, allPersonPartSegmentation;
        var _this = this;
        return __generator(this, function (_e) {
            switch (_e.label) {
                case 0:
                    posesAboveScore = poses.filter(function (pose) { return pose.score >= minPoseScore; });
                    masksTensor = decodeMultipleMasksTensorGPU(segmentation, longOffsets, posesAboveScore, height, width, stride, [inHeight, inWidth], [[padT, padB], [padL, padR]], refineSteps, minKeypointScore, maxNumPeople);
                    return [4 /*yield*/, Promise.all(posesAboveScore.map(function (pose, i) { return __awaiter(_this, void 0, void 0, function () {
                            var data;
                            return __generator(this, function (_a) {
                                switch (_a.label) {
                                    case 0: return [4 /*yield*/, toPersonKPartSegmentation(masksTensor, partSegmentation, i)
                                            .data()];
                                    case 1:
                                        data = (_a.sent());
                                        return [2 /*return*/, { height: height, width: width, data: data, pose: pose }];
                                }
                            });
                        }); }))];
                case 1:
                    allPersonPartSegmentation = _e.sent();
                    return [2 /*return*/, allPersonPartSegmentation];
            }
        });
    });
}
exports.decodeMultiplePartMasksGPU = decodeMultiplePartMasksGPU;
