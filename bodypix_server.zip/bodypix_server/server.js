var body_pix_model_1 = require("./body_pix_model");
const BodyPix = body_pix_model_1.BodyPix;
const load = body_pix_model_1.load;
const tf = require('@tensorflow/tfjs-node');
const fs = require("fs");
const { createCanvas, loadImage, drawImage,Image } = require('canvas')
var express = require('express');
const bodyParser = require('body-parser');
var multer = require('multer');
var upload = multer();


var app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(upload.array());
app.use(express.static(__dirname + '/public'));
app.use(bodyParser.json());


var net="";
var k="";

async function loadmodel()
{
  net = await load({
  architecture: 'MobileNetV1',
  outputStride: 16,
  multiplier: 0.75,
  quantBytes: 2
  });
}

async function loadAndPredict(source,net) 
{
  const img = new Image()
  img.src = source
  console.log(source+"   water")
  img.onload = () => ctx.drawImage(img, 0, 0)
  img.onerror = err => { throw err }
  var height = img.height;
  var width = img.width ;
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');
  ctx.drawImage(img, 0, 0, width, height);
  const test = canvas

  const segmentation = await net.segmentPersonParts(test, {
  flipHorizontal: false,
  internalResolution: 'medium',
  segmentationThreshold: 0.7
});
  
   k=segmentation.data.join(','), (err) => {if (err) throw err;}
}

app.get('/', function(req, res){
  
 res.send("index.html"); 
});

app.get('/getpoints', function (req, res) {
  console.log(req.body)
  loadAndPredict(req.body.source,net).then(()=>{res.send(k)})
   
})


loadmodel().then(()=>{
  console.log("model loding....")

  var server = app.listen(8080, function () {
   var host = server.address().address
   var port = server.address().port

   console.log("*******************************************************")
   console.log("*******************************************************")
   console.log("\nBodyPix app listening at http://%s:%s\n", host, port)
   console.log("*******************************************************")
   console.log("*******************************************************")
})


})


