var body_pix_model_1 = require("./body_pix_model");
const BodyPix = body_pix_model_1.BodyPix;
const load = body_pix_model_1.load;
const tf = require('@tensorflow/tfjs');
const fs = require("fs");
const { createCanvas, loadImage, drawImage,Image } = require('canvas')


const img = new Image()
img.src = '5.jpg'
img.onload = () => ctx.drawImage(img, 0, 0)
img.onerror = err => { throw err }
var height = img.height;
var width = img.width ;
const canvas = createCanvas(width, height);
const ctx = canvas.getContext('2d');
ctx.drawImage(img, 0, 0, width, height);
tf.browser.fromPixels(canvas).print();

const test = canvas

async function loadAndPredict() {
  const net = await load({
  architecture: 'MobileNetV1',
  outputStride: 16,
  multiplier: 0.75,
  quantBytes: 2
  });
  const segmentation = await net.segmentPersonParts(test, {
  flipHorizontal: false,
  internalResolution: 'medium',
  segmentationThreshold: 0.7
});
  console.log(segmentation);
  fs.writeFile('5.txt', segmentation.data.join(','), (err) => {if (err) throw err;}) 
   console.log("written 5")
}
loadAndPredict();