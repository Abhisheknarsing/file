"use strict";
/**
 * @license
 * Copyright 2019 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
exports.__esModule = true;
var tf = require("@tensorflow/tfjs-core");
var VALID_OUTPUT_STRIDES = [8, 16, 32];
// tslint:disable-next-line:no-any
function assertValidOutputStride(outputStride) {
    tf.util.assert(typeof outputStride === 'number', function () { return 'outputStride is not a number'; });
    tf.util.assert(VALID_OUTPUT_STRIDES.indexOf(outputStride) >= 0, function () { return "outputStride of " + outputStride + " is invalid. " +
        "It must be either 8, 16, or 32"; });
}
exports.assertValidOutputStride = assertValidOutputStride;
// tslint:disable-next-line:no-any
function assertValidResolution(resolution, outputStride) {
    tf.util.assert(typeof resolution === 'number', function () { return 'resolution is not a number'; });
    tf.util.assert((resolution - 1) % outputStride === 0, function () { return "resolution of " + resolution + " is invalid for output stride " +
        (outputStride + "."); });
}
exports.assertValidResolution = assertValidResolution;
function toFloatIfInt(input) {
    return tf.tidy(function () {
        if (input.dtype === 'int32') {
            input = input.toFloat();
        }
        return input;
    });
}
function processInput(input) {
    return tf.tidy(function () {
        // Normalize the pixels [0, 255] to be between [-1, 1].
        return tf.div(input, 127.5).sub(1.0);
    });
}
var MobileNet = /** @class */ (function () {
    function MobileNet(model, outputStride) {
        this.model = model;
        var inputShape = this.model.inputs[0].shape;
        tf.util.assert((inputShape[1] === -1) && (inputShape[2] === -1), function () { return "Input shape [" + inputShape[1] + ", " + inputShape[2] + "] " +
            "must both be -1"; });
        this.outputStride = outputStride;
    }
    MobileNet.prototype.predict = function (input) {
        var _this = this;
        return tf.tidy(function () {
            var asFloat = processInput(toFloatIfInt(input));
            var asBatch = asFloat.expandDims(0);
            var _a = _this.model.predict(asBatch), offsets4d = _a[0], segmentation4d = _a[1], partHeatmaps4d = _a[2], longOffsets4d = _a[3], heatmaps4d = _a[4], displacementFwd4d = _a[5], displacementBwd4d = _a[6], partOffsets4d = _a[7];
            var heatmaps = heatmaps4d.squeeze();
            var heatmapScores = heatmaps.sigmoid();
            var offsets = offsets4d.squeeze();
            var displacementFwd = displacementFwd4d.squeeze([0]);
            var displacementBwd = displacementBwd4d.squeeze([0]);
            var segmentation = segmentation4d.squeeze([0]);
            var partHeatmaps = partHeatmaps4d.squeeze([0]);
            var longOffsets = longOffsets4d.squeeze([0]);
            var partOffsets = partOffsets4d.squeeze([0]);
            return {
                heatmapScores: heatmapScores,
                offsets: offsets,
                displacementFwd: displacementFwd,
                displacementBwd: displacementBwd,
                segmentation: segmentation,
                partHeatmaps: partHeatmaps,
                longOffsets: longOffsets,
                partOffsets: partOffsets
            };
        });
    };
    MobileNet.prototype.dispose = function () {
        this.model.dispose();
    };
    return MobileNet;
}());
exports.MobileNet = MobileNet;
